package com.sosmena.mvvm;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PlantViewHolder extends RecyclerView.ViewHolder {
    ImageView img;
    TextView title, price;

    public PlantViewHolder(@NonNull View view) {
        super(view);
        img = view.findViewById(R.id.imageview);
        title = view.findViewById(R.id.productName);
        price = view.findViewById(R.id.productPrice);
    }
}