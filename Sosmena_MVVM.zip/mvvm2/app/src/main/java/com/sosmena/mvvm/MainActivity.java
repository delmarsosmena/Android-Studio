package com.sosmena.mvvm;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView rv = findViewById(R.id.recyclerview);

        List<PlantItem> plantList = new ArrayList<>();

        plantList.add(new PlantItem(R.drawable.monstera, "Monstera Albo", "P12,000"));
        plantList.add(new PlantItem(R.drawable.philodendron, "Pink Princess", "P8,500"));
        plantList.add(new PlantItem(R.drawable.bonsai, "Juniper Bonsai", "P15,000"));
        plantList.add(new PlantItem(R.drawable.snake_plant, "Snake Plant Laurentii", "P1,200"));
        plantList.add(new PlantItem(R.drawable.cactus, "Golden Barrel Cactus", "P2,500"));
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(new PlantAdapter(this, plantList));
    }
}