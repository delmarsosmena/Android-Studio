package com.sosmena.mvvm;

public class PlantItem {
    private int image;
    private String plantName;
    private String plantPrice;

    public PlantItem(int image, String plantName, String plantPrice) {
        this.image = image;
        this.plantName = plantName;
        this.plantPrice = plantPrice;
    }

    public int getImage() { return image; }
    public String getPlantName() { return plantName; }
    public String getPlantPrice() { return plantPrice; }
}