package com.sosmena.mvvm;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class PlantAdapter extends RecyclerView.Adapter<PlantViewHolder> {
    Context c;
    List<PlantItem> data;

    public PlantAdapter(Context c, List<PlantItem> data) {
        this.c = c;
        this.data = data;
    }

    @NonNull
    @Override
    public PlantViewHolder onCreateViewHolder(@NonNull ViewGroup p, int vt) {
        return new PlantViewHolder(LayoutInflater.from(c).inflate(R.layout.items, p, false));
    }

    @Override
    public void onBindViewHolder(@NonNull PlantViewHolder h, int pos) {
        PlantItem item = data.get(pos);
        h.img.setImageResource(item.getImage());
        h.title.setText(item.getPlantName());
        h.price.setText(item.getPlantPrice());
    }

    @Override
    public int getItemCount() { return data.size(); }
}